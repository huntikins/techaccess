
- Documentation:
    http://drupal.org/node/1300810

- LDAP Feeds Example: Synch LDAP Data to Drupal User
    http://drupal.org/node/1300812

- LDAP Feeds Query Fetcher Example:
    http://drupal.org/node/1300822
